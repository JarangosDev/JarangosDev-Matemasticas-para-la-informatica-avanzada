public class MecatronicStundent {

    String carreer = "Mecatronica";
    String name = "";
    String gender = "";
    double[] notes;
    public MecatronicStundent( String name, String gender, double[] notes) {
        this.carreer = carreer;
        this.name = name;
        this.gender = gender;
        this.notes = notes;
    }



}
