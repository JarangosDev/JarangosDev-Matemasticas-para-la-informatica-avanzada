public class TelecomunicationStudent {
    String carreer = "Mecatronica";
    String name = "";
    String gender = "";
    double[] notes;

    public TelecomunicationStudent(String name, String gender, double[] notes) {
        this.carreer = carreer;
        this.name = name;
        this.gender = gender;
        this.notes = notes;
    }
}
